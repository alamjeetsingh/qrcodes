# Label Verification API

## Overview
This is a FastAPI-based service for generating and verifying labels with QR codes and AI-generated noise patterns.

## Installation
1. Clone the repository
   ```bash
   git clone https://github.com/YOUR_GITHUB_REPO.git
   cd label-verification-api
   ```

2. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```

3. Run the application
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```

## API Endpoints
- `POST /generate_label/` - Generates a label with QR code and AI noise
- `POST /verify_label/` - Verifies a label against stored noise hash
