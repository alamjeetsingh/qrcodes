from fastapi import FastAPI
from app.label_generator import generate_label
from app.label_verifier import verify_label

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Label Verification API is running"}

@app.post("/generate_label/")
def create_label(product_id: str, serial_number: str):
    label_path, noise_hash = generate_label(product_id, serial_number)
    return {"label": label_path, "noise_hash": noise_hash}

@app.post("/verify_label/")
def check_label(qr_data: str, noise_hash: str):
    is_valid, message = verify_label(qr_data, noise_hash)
    return {"valid": is_valid, "message": message}
