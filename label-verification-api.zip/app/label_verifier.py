import hashlib
import numpy as np
from PIL import Image

def verify_label(qr_data, scanned_noise_path):
    try:
        scanned_noise = Image.open(scanned_noise_path).convert("L")
        noise_hash = hashlib.sha256(np.array(scanned_noise).tobytes()).hexdigest()

        stored_hash = "FAKE_HASH_FROM_DB"

        if noise_hash == stored_hash:
            return True, "Label is valid"
        return False, "Fake Label Detected!"
    except Exception as e:
        return False, f"Error: {str(e)}"
