import qrcode
import numpy as np
from PIL import Image, ImageDraw
import hashlib

def generate_ai_noise(seed, size=(200, 200)):
    np.random.seed(seed)
    noise = np.random.randint(0, 256, size=size, dtype=np.uint8)
    return Image.fromarray(noise, mode="L")

def generate_label(product_id, serial_number):
    data = f"{product_id}-{serial_number}"
    qr = qrcode.make(data).convert("L")

    seed = hash(data) % (2**32)
    noise_img = generate_ai_noise(seed, (qr.size[0] + 40, qr.size[1] + 40))

    label_img = Image.new("L", noise_img.size, color=255)
    label_img.paste(noise_img, (0, 0))
    label_img.paste(qr, (20, 20))

    noise_hash = hashlib.sha256(np.array(noise_img).tobytes()).hexdigest()

    filename = f"static/test_labels/{product_id}_{serial_number}.png"
    label_img.save(filename)

    return filename, noise_hash
